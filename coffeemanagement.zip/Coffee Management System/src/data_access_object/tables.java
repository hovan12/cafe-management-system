 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data_access_object;

import javax.swing.JOptionPane;
/**
 *
 * @author Hovan Kendrik
 */
public class tables {
    public static void main (String[] args){ 
    try {
     String userTable = "create table user (id int AUTO_INCREMENT primary key,name varchar(50),email varchar(50),mobileNumber varchar(11),address varchar(50),password varchar(50),securityQuestion varchar(50),answer varchar(50),status varchar(50), UNIQUE(email))";
       String adminDetails = "insert into user(Name,Email,MobileNumber,Address,Password,SecurityQuestion,Answer,Status ) values('Admin','admin@gmail.com','09666947545','Bohol','admin','What school are you from?','BISU balilihan','true')";
        String categoryTable = "create table category(ID int AUTO_INCREMENT primary key,Name varchar(30))";
        String productTable =  "create table product(id int AUTO_INCREMENT primary key, name varchar(100), category varchar(100), price varchar(100))";
        String billTable = "create table bill(ID int primary key,Name varchar(30),mobileNumber varchar(11),email varchar(50),date varchar(50),total varchar(50),createdBy varchar(50))";
     DbOperations.setDataOrDelete(userTable, "User Table Created Successfully");
        DbOperations.setDataOrDelete(adminDetails, "Admin Details Added Successfully");
        DbOperations.setDataOrDelete(categoryTable, "Category Table Created Successfully");
        DbOperations.setDataOrDelete(productTable, "Product Table Created Successfully");
        DbOperations.setDataOrDelete(billTable, "Bill Table Created Successfully");
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null, e); 
    }
    }   
}