/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data_access_object;
import java.sql.*;
/**
 *
 * @author Hovan Kendrik
 */
public class connectionProvider {
    public static Connection getCon(){
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CoffeeManagementSystem?SSL=false","root","hovan123!@#");
        return con;
       
    }
    catch(ClassNotFoundException | SQLException e){
        return null;
    }
    }
}


