/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package common;


import java.awt.Desktop;
import javax.swing.JOptionPane;
import java.io.File;

/**
 *
 * @author Hovan Kendrik
 */
public class openPdf {
    public static void openById(String id){
        try {
//             String userHome = System.getProperty("user.home");
//            String path = userHome + "\\Documents\\";  // File path from the user's Documents;
//            File pdfFile = new File(path + id + ".pdf");  // Generate file path using the bill ID
            
            // Check if the file exists
            if (new File("C:\\ "+id+".pdf") .exists()) {
                // Open the file using the default file handler
                Process p = Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler C:\\"+id+".pdf");
            } else {
                JOptionPane.showMessageDialog(null, "File does not exist.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error opening PDF: " + e.getMessage());
        }
    }
}